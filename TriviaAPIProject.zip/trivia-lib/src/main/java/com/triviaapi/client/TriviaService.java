package com.triviaapi.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.triviaapi.model.TriviaResponse;
import org.apache.commons.text.StringEscapeUtils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class TriviaService {
    private static final String API_URL = "https://opentdb.com/api.php"; // URL για ερωτήσεις
    private static final String CATEGORY_URL = "https://opentdb.com/api_category.php"; // URL για κατηγορίες
    private final ObjectMapper objectMapper = new ObjectMapper(); // Μετατροπέας JSON σε Java αντικείμενα

    /** Ανάκτηση ερωτήσεων από το Open Trivia API */
    public TriviaResponse fetchQuestions(int amount, String type, String category, String difficulty) throws IOException {
        StringBuilder apiUrl = new StringBuilder(API_URL);
        apiUrl.append("?amount=").append(amount);
        if (type != null) apiUrl.append("&type=").append(type);
        if (category != null) apiUrl.append("&category=").append(category);
        if (difficulty != null) apiUrl.append("&difficulty=").append(difficulty);

        // Εκτύπωση του URL για έλεγχο
        System.out.println("Ανάκτηση ερωτήσεων από: " + apiUrl);

        String response = getApiResponse(apiUrl.toString());

        // Εκτύπωση της αρχικής απόκρισης JSON για έλεγχο
        System.out.println("Απάντηση API: " + response);

        // Μετατροπή της JSON απάντησης σε Java αντικείμενο
        TriviaResponse triviaResponse = objectMapper.readValue(response, TriviaResponse.class);

        // Αφαίρεση HTML χαρακτήρων από τις ερωτήσεις και τις απαντήσεις
        triviaResponse.getResults().forEach(q -> {
            q.setQuestion(StringEscapeUtils.unescapeHtml4(q.getQuestion())); // Διόρθωση ερώτησης
            q.setCorrectAnswer(StringEscapeUtils.unescapeHtml4(q.getCorrectAnswer())); // Διόρθωση σωστής απάντησης
            q.setIncorrectAnswers(q.getIncorrectAnswers().stream()
                    .map(StringEscapeUtils::unescapeHtml4).toList()); // Διόρθωση λανθασμένων απαντήσεων
        });

        return triviaResponse;
    }

    /** Ανάκτηση κατηγοριών από το API και επιστροφή ως Map */
    public Map<String, String> fetchCategories() throws IOException {
        String response = getApiResponse(CATEGORY_URL);
        Map<String, String> categoryMap = new LinkedHashMap<>();
        categoryMap.put("Όλες οι Κατηγορίες", null); // Προεπιλογή για όλες τις κατηγορίες

        JsonNode categoriesNode = objectMapper.readTree(response).get("trivia_categories");

        if (categoriesNode.isArray()) {
            for (JsonNode category : categoriesNode) {
                String name = category.get("name").asText(); // Λήψη ονόματος κατηγορίας
                String id = category.get("id").asText(); // Λήψη ID κατηγορίας
                categoryMap.put(name, id);
            }
        }

        return categoryMap;
    }

    /** Μέθοδος βοηθός για αποστολή HTTP αιτήσεων και ανάκτηση απαντήσεων */
    private String getApiResponse(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        Scanner scanner = new Scanner(conn.getInputStream());
        StringBuilder jsonResponse = new StringBuilder();
        while (scanner.hasNext()) {
            jsonResponse.append(scanner.nextLine());
        }
        scanner.close();

        return jsonResponse.toString();
    }
}
