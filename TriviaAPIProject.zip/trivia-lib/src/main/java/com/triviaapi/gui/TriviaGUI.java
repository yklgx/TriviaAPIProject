package com.triviaapi.gui;

import com.triviaapi.client.TriviaService;
import com.triviaapi.model.Question;
import com.triviaapi.model.TriviaResponse;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class TriviaGUI extends Application {
    private TriviaService triviaService = new TriviaService();
    private Map<String, String> categoryMap;
    private List<Question> questions;
    private int currentQuestionIndex = 0, score = 0, maxScore = 0;

    private Label questionLabel, scoreLabel;
    private VBox answerButtons;
    private Button nextButton;
    private ComboBox<String> categoryBox, difficultyBox, typeBox;
    private TextField questionCountField;
    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        loadCategories();
    }

    /**  Ανάκτηση κατηγοριών πριν εμφανιστεί η οθόνη ρυθμίσεων */
    private void loadCategories() {
        try {
            categoryMap = triviaService.fetchCategories();
        } catch (IOException e) {
            System.out.println("Αποτυχία φόρτωσης κατηγοριών. Χρήση προεπιλεγμένης.");
            categoryMap = Map.of("Όλες οι κατηγορίες", null);
        }
        showSettingsScreen();
    }

    /**  Οθόνη επιλογής ρυθμίσεων παιχνιδιού */
    private void showSettingsScreen() {
        Label title = new Label("Ρυθμίσεις Παιχνιδιού");

        //  Επιλογή κατηγορίας
        categoryBox = new ComboBox<>();
        categoryBox.getItems().addAll(categoryMap.keySet());
        categoryBox.setValue("Όλες οι κατηγορίες");

        //  Επιλογή δυσκολίας
        difficultyBox = new ComboBox<>();
        difficultyBox.getItems().addAll("easy", "medium", "hard");
        difficultyBox.setValue("medium");

        //  Επιλογή τύπου ερώτησης
        typeBox = new ComboBox<>();
        typeBox.getItems().addAll("multiple", "boolean");
        typeBox.setValue("multiple");

        //  Επιλογή αριθμού ερωτήσεων
        questionCountField = new TextField("5");

        // Κουμπί έναρξης παιχνιδιού
        Button startButton = new Button("Ξεκίνα Παιχνίδι");
        startButton.setOnAction(e -> fetchQuestions());

        VBox layout = new VBox(10, title, new Label("Κατηγορία:"), categoryBox, 
                new Label("Δυσκολία:"), difficultyBox, new Label("Τύπος:"), typeBox, 
                new Label("Αριθμός Ερωτήσεων:"), questionCountField, startButton);
        layout.setAlignment(Pos.CENTER);

        primaryStage.setScene(new Scene(layout, 400, 400));
        primaryStage.setTitle("Παιχνίδι Γνώσεων - Ρυθμίσεις");
        primaryStage.show();
    }

    /**  Ανάκτηση ερωτήσεων από το API */
    private void fetchQuestions() {
        int questionCount = Integer.parseInt(questionCountField.getText());
        String category = categoryMap.get(categoryBox.getValue());
        String difficulty = difficultyBox.getValue();
        String type = typeBox.getValue();

        try {
            TriviaResponse response = triviaService.fetchQuestions(questionCount, type, category, difficulty);
            questions = response.getResults();

            if (questions == null || questions.isEmpty()) {
                showErrorMessage("Δεν βρέθηκαν ερωτήσεις. Δοκιμάστε ξανά με διαφορετικές ρυθμίσεις.");
                return;
            }

            currentQuestionIndex = 0;
            score = 0;
            showQuestionScreen();
        } catch (IOException e) {
            showErrorMessage("Σφάλμα σύνδεσης με το API.");
        }
    }

    /**  Οθόνη προβολής ερωτήσεων */
    private void showQuestionScreen() {
        questionLabel = new Label();
        questionLabel.setWrapText(true);
        questionLabel.setStyle("-fx-font-size: 16px;");

        scoreLabel = new Label("Σκορ: 0");

        answerButtons = new VBox(10);
        answerButtons.setAlignment(Pos.CENTER); //  Κεντράρισμα κουμπιών απαντήσεων

        nextButton = new Button("Επόμενη Ερώτηση");
        nextButton.setDisable(true);
        nextButton.setOnAction(e -> nextQuestion());

        VBox layout = new VBox(20, questionLabel, answerButtons, scoreLabel, nextButton);
        layout.setAlignment(Pos.CENTER); //  Κεντράρισμα όλων των στοιχείων

        primaryStage.setScene(new Scene(layout, 600, 400));
        showQuestion();
    }

    /** Εμφάνιση της επόμενης ερώτησης */
    private void showQuestion() {
        if (currentQuestionIndex >= questions.size()) {
            showResultsScreen();
            return;
        }

        Question question = questions.get(currentQuestionIndex);
        questionLabel.setText((currentQuestionIndex + 1) + ". " + question.getQuestion());

        //  Δημιουργία νέας λίστας για να αποφευχθεί UnsupportedOperationException
        List<String> allAnswers = new ArrayList<>(question.getIncorrectAnswers());
        allAnswers.add(question.getCorrectAnswer());
        Collections.shuffle(allAnswers);

        answerButtons.getChildren().clear();
        answerButtons.setAlignment(Pos.CENTER); //  Διατήρηση του κεντραρίσματος των κουμπιών

        for (String answer : allAnswers) {
            Button answerButton = new Button(answer);
            answerButton.setMinWidth(300); //  Ορισμός σταθερού πλάτους στα κουμπιά
            answerButton.setOnAction(e -> checkAnswer(answer, question.getCorrectAnswer(), answerButton));
            answerButtons.getChildren().add(answerButton);
        }

        nextButton.setDisable(true);
    }

    /**  Έλεγχος της απάντησης του χρήστη */
    private void checkAnswer(String selectedAnswer, String correctAnswer, Button clickedButton) {
        if (selectedAnswer.equals(correctAnswer)) {
            score += 10;
            clickedButton.setStyle("-fx-background-color: lightgreen;");
        } else {
            clickedButton.setStyle("-fx-background-color: red;");
        }

        scoreLabel.setText("Σκορ: " + score);
        nextButton.setDisable(false);
    }

    /**  Μετάβαση στην επόμενη ερώτηση */
    private void nextQuestion() {
        currentQuestionIndex++;
        showQuestion();
    }

    /**  Εμφάνιση της οθόνης αποτελεσμάτων */
    private void showResultsScreen() {
        if (score > maxScore) {
            maxScore = score;
        }

        Label resultLabel = new Label("Παιχνίδι Τέλος! Το τελικό σου σκορ: " + score);
        Label maxScoreLabel = new Label("Καλύτερο Σκορ: " + maxScore);

        Button playAgainButton = new Button("Παίξε Ξανά");
        playAgainButton.setOnAction(e -> showSettingsScreen());

        VBox layout = new VBox(20, resultLabel, maxScoreLabel, playAgainButton);
        layout.setAlignment(Pos.CENTER);

        primaryStage.setScene(new Scene(layout, 400, 300));
    }

    /**  Εμφάνιση μηνύματος σφάλματος */
    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Σφάλμα");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
