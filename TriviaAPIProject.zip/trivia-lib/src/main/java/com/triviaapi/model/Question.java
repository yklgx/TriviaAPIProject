package com.triviaapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Η κλάση αυτή αναπαριστά μία ερώτηση γνώσεων που λαμβάνεται από το API του Open Trivia DB.
 * Χρησιμοποιείται για τη χαρτογράφηση των δεδομένων JSON σε ένα αντικείμενο Java.
 */
public class Question {

    // Ο τύπος της ερώτησης (π.χ. "multiple" για ερωτήσεις πολλαπλής επιλογής, "boolean" για σωστό/λάθος)
    @JsonProperty("type")
    private String type;

    // Το επίπεδο δυσκολίας της ερώτησης (π.χ. "easy", "medium", "hard")
    @JsonProperty("difficulty")
    private String difficulty;

    // Η κατηγορία στην οποία ανήκει η ερώτηση (π.χ. "Science: Computers")
    @JsonProperty("category")
    private String category;

    // Το κείμενο της ερώτησης
    @JsonProperty("question")
    private String question;

    // Η σωστή απάντηση στην ερώτηση
    @JsonProperty("correct_answer")
    private String correctAnswer;

    // Η λίστα με τις λανθασμένες απαντήσεις
    @JsonProperty("incorrect_answers")
    private List<String> incorrectAnswers;

    // Μέθοδοι Getter και Setter για κάθε πεδίο

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getQuestion() { return question; }
    public void setQuestion(String question) { this.question = question; }

    public String getCorrectAnswer() { return correctAnswer; }
    public void setCorrectAnswer(String correctAnswer) { this.correctAnswer = correctAnswer; }

    public List<String> getIncorrectAnswers() { return incorrectAnswers; }
    public void setIncorrectAnswers(List<String> incorrectAnswers) { this.incorrectAnswers = incorrectAnswers; }

    /**
     * Επιστρέφει μια συμβολοσειρά που περιέχει όλες τις πληροφορίες της ερώτησης.
     * Χρήσιμο για debugging.
     */
    @Override
    public String toString() {
        return "Question{" +
                "category='" + category + '\'' +
                ", type='" + type + '\'' +
                ", difficulty='" + difficulty + '\'' +
                ", question='" + question + '\'' +
                ", correctAnswer='" + correctAnswer + '\'' +
                ", incorrectAnswers=" + incorrectAnswers +
                '}';
    }
}
