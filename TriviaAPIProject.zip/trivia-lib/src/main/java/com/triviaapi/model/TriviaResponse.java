package com.triviaapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Η κλάση αυτή χρησιμοποιείται για την αναπαράσταση της απόκρισης του Open Trivia DB API.
 * Περιέχει τον κωδικό απόκρισης και μια λίστα με ερωτήσεις.
 */
@JsonIgnoreProperties(ignoreUnknown = true) // Αγνοεί τυχόν επιπλέον πεδία στο JSON που δεν υπάρχουν εδώ
public class TriviaResponse {

    // Κωδικός απόκρισης του API (0 σημαίνει επιτυχής απάντηση, άλλοι αριθμοί δείχνουν σφάλματα)
    @JsonProperty("response_code")
    private Integer responseCode;

    // Λίστα με τις ερωτήσεις που επιστρέφονται από το API
    @JsonProperty("results")
    private List<Question> results;

    // Μέθοδοι Getter και Setter για πρόσβαση στα δεδομένα της κλάσης

    /**
     * Επιστρέφει τον κωδικό απόκρισης του API.
     * @return Ο αριθμητικός κωδικός απόκρισης.
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * Ορίζει τον κωδικό απόκρισης του API.
     * @param responseCode Ο νέος κωδικός απόκρισης.
     */
    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * Επιστρέφει τη λίστα με τις ερωτήσεις που επιστράφηκαν από το API.
     * @return Λίστα αντικειμένων τύπου `Question`.
     */
    public List<Question> getResults() {
        return results;
    }

    /**
     * Ορίζει τη λίστα των ερωτήσεων.
     * @param results Η νέα λίστα με τις ερωτήσεις.
     */
    public void setResults(List<Question> results) {
        this.results = results;
    }

    /**
     * Επιστρέφει μια συμβολοσειρά που περιέχει πληροφορίες της απόκρισης.
     * Χρήσιμο για debugging.
     */
    @Override
    public String toString() {
        return "TriviaResponse{" +
                "responseCode=" + responseCode +
                ", results=" + results +
                '}';
    }
}
