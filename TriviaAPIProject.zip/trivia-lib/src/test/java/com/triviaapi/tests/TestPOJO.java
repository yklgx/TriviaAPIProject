package com.triviaapi.tests;

import com.triviaapi.model.Question;
import com.triviaapi.model.TriviaResponse;

import java.util.Arrays;
import java.util.List;

public class TestPOJO {
    public static void main(String[] args) {
        // Δημιουργία μιας ερώτησης για δοκιμή
    	 Question q = new Question();
         q.setCategory("Football: Teams");
         q.setType("multiple");
         q.setDifficulty("medium");
         q.setQuestion("Who won Champions League in 2010?");
         q.setCorrectAnswer("Inter Milan");
         q.setIncorrectAnswers(Arrays.asList("Bayern Munich", "Manchester United", "Real Madrid"));

        // Εκτύπωση της ερώτησης
        System.out.println(q);

        // Δημιουργία αντικειμένου TriviaResponse
        TriviaResponse response = new TriviaResponse();
        response.setResponseCode(0);
        response.setResults(List.of(q));

        // Εκτύπωση της συνολικής απόκρισης
        System.out.println(response);
    }
}

