package com.triviaapi.tests;

import com.triviaapi.client.TriviaService;
import com.triviaapi.model.Question;
import com.triviaapi.model.TriviaResponse;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class TriviaConsole {
    public static void main(String[] args) {
        try {
            // Ανάκτηση ερωτήσεων από το Trivia API
            TriviaService triviaService = new TriviaService();
            TriviaResponse response = triviaService.fetchQuestions(5, "multiple", null, "medium");
            List<Question> questions = response.getResults();

            // Έλεγχος αν ανακτήθηκαν ερωτήσεις
            if (questions == null || questions.isEmpty()) {
                System.out.println("Δεν βρέθηκαν ερωτήσεις.");
                return;
            }

            // Εμφάνιση των ερωτήσεων και απαντήσεων
            for (Question q : questions) {
                System.out.println("\nΕρώτηση: " + q.getQuestion());

                // Δημιουργία νέας λίστας για να αποφεύγεται το UnsupportedOperationException
                List<String> allAnswers = new ArrayList<>(q.getIncorrectAnswers());
                allAnswers.add(q.getCorrectAnswer());
                Collections.shuffle(allAnswers); // Τυχαία αναδιάταξη των απαντήσεων

                // Εκτύπωση των πιθανών απαντήσεων
                for (int i = 0; i < allAnswers.size(); i++) {
                    System.out.println((i + 1) + ". " + allAnswers.get(i));
                }

                // Εμφάνιση σωστής απάντησης (για δοκιμές)
                System.out.println("Σωστή απάντηση: " + q.getCorrectAnswer());
            }

        } catch (IOException e) {
            System.out.println("Σφάλμα κατά την ανάκτηση ερωτήσεων.");
        }
    }
}
