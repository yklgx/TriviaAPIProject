package com.triviaapi.tests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.triviaapi.client.TriviaService;
import com.triviaapi.model.Question;
import com.triviaapi.model.TriviaResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Κλάση δοκιμών για την `TriviaService`, η οποία ελέγχει αν η υπηρεσία επιστρέφει σωστά δεδομένα.
 * Χρησιμοποιεί το Mockito για προσομοίωση απαντήσεων από το API.
 */
public class TriviaServiceTest {

    @Test
    public void testFetchQuestionsReturnsValidResponse() throws IOException {
        // Δημιουργία mock αντικειμένου για το TriviaService
        TriviaService triviaService = Mockito.mock(TriviaService.class);

        // Δημιουργία ψεύτικης ερώτησης (mock δεδομένα)
        Question mockQuestion = new Question();
        mockQuestion.setQuestion("Who won 2010 Champions League"); // Το ερώτημα
        mockQuestion.setCorrectAnswer("Inter Milan"); // Η σωστή απάντηση
        mockQuestion.setIncorrectAnswers(Arrays.asList("Bayern Munich", "Manchester United", "Barcelona FC")); // Οι λανθασμένες απαντήσεις

        // Δημιουργία mock απάντησης του API
        TriviaResponse mockResponse = new TriviaResponse();
        mockResponse.setResults(List.of(mockQuestion));

        // Καθορισμός συμπεριφοράς mock: Εάν κληθεί το `fetchQuestions`, να επιστρέψει το `mockResponse`
        when(triviaService.fetchQuestions(1, "multiple", null, "medium")).thenReturn(mockResponse);

        // Κλήση της μεθόδου `fetchQuestions`
        TriviaResponse response = triviaService.fetchQuestions(1, "multiple", null, "medium");

        // Έλεγχος αν η απόκριση δεν είναι null
        assertNotNull(response);

        // Έλεγχος αν επιστρέφεται μόνο μία ερώτηση
        assertEquals(1, response.getResults().size());

        // Έλεγχος αν η ερώτηση που επιστράφηκε είναι η σωστή
        assertEquals("Who won 2010 Champions League", response.getResults().get(0).getQuestion());
    }
}
