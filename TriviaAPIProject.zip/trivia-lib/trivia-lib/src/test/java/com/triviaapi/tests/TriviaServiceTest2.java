package com.triviaapi.tests;

import com.triviaapi.client.TriviaService;
import com.triviaapi.model.Question;
import com.triviaapi.model.TriviaResponse;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Κλάση δοκιμών για την `TriviaService2`, η οποία ελέγχει αν η υπηρεσία επιστρέφει σωστά δεδομένα.
 * Ελέγχουμε την ανάκτηση ερωτήσεων από το API και αν τα δεδομένα που επιστρέφονται είναι έγκυρα.
 */
public class TriviaServiceTest2 {

    /**
     * Δοκιμή που ελέγχει αν το API επιστρέφει τον σωστό αριθμό ερωτήσεων.
     * @throws IOException αν αποτύχει η σύνδεση με το API.
     */
    @Test
    public void testFetchQuestionsReturnsCorrectAmount() throws IOException {
        TriviaService triviaService = new TriviaService();

        // Ανάκτηση 5 ερωτήσεων από το API
        TriviaResponse response = triviaService.fetchQuestions(5, "multiple", null, "medium");

        // Βεβαιωνόμαστε ότι η απόκριση δεν είναι null
        assertNotNull(response, "Η απόκριση από το API δεν πρέπει να είναι null");

        // Βεβαιωνόμαστε ότι η λίστα των ερωτήσεων δεν είναι κενή
        assertNotNull(response.getResults(), "Η λίστα των ερωτήσεων δεν πρέπει να είναι null");

        // Βεβαιωνόμαστε ότι επιστράφηκαν ακριβώς 5 ερωτήσεις
        assertEquals(5, response.getResults().size(), "Αναμένονταν 5 ερωτήσεις, αλλά ελήφθησαν " + response.getResults().size());
    }


    /**
     * Δοκιμή που ελέγχει αν οι ερωτήσεις περιέχουν έγκυρα δεδομένα.
     * @throws IOException αν αποτύχει η σύνδεση με το API.
     */
@Test
public void testFetchQuestionsContainValidData() throws IOException {
    TriviaService triviaService = new TriviaService();

    // Ανάκτηση 3 ερωτήσεων από το API
    TriviaResponse response = triviaService.fetchQuestions(3, "multiple", null, "medium");
    List<Question> questions = response.getResults();

    // Έλεγχος όλων των ερωτήσεων στη λίστα
    for (Question q : questions) {
        assertNotNull(q.getQuestion(), "Το κείμενο της ερώτησης δεν πρέπει να είναι null");
        assertNotNull(q.getCorrectAnswer(), "Η σωστή απάντηση δεν πρέπει να είναι null");
        assertNotNull(q.getIncorrectAnswers(), "Η λίστα των λανθασμένων απαντήσεων δεν πρέπει να είναι null");
        assertFalse(q.getIncorrectAnswers().isEmpty(), "Η λίστα των λανθασμένων απαντήσεων δεν πρέπει να είναι κενή");
    }
}
}
